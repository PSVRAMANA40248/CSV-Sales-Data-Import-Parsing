package sales;

public record ParseError(
        int lineNumber,
        String rawLine,
        String message
) {
}
