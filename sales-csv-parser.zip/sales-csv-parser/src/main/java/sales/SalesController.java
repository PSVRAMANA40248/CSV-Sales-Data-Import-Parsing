package sales;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class SalesController {

    private final SalesCsvParser parser = new SalesCsvParser();

    @PostMapping("/parse")
    public ResponseEntity<ParseResult> parseCsv(@RequestParam("file") MultipartFile file) {
        try {
            Path tempFile = Files.createTempFile("sales", ".csv");
            file.transferTo(tempFile);
            
            ParseResult result = parser.parse(tempFile);
            
            Files.deleteIfExists(tempFile);
            
            return ResponseEntity.ok(result);
        } catch (IOException e) {
            return ResponseEntity.internalServerError().build();
        }
    }
}
