package sales;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Collectors;

public class SimpleServer {
    private static final int PORT = 8080;
    private static final SalesCsvParser parser = new SalesCsvParser();

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", PORT), 0);
        
        server.createContext("/", new FileHandler());
        server.createContext("/api/parse", new ParseHandler());
        
        server.setExecutor(null);
        server.start();
        
        // Get local IP address
        String localIP = java.net.InetAddress.getLocalHost().getHostAddress();
        
        System.out.println("Server started!");
        System.out.println("Local access: http://localhost:" + PORT);
        System.out.println("Network access: http://" + localIP + ":" + PORT);
        System.out.println("Press Ctrl+C to stop the server");
    }

    static class FileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();
            
            if (path.equals("/")) {
                path = "/index.html";
            }
            
            Path filePath = Path.of("src/main/resources/static" + path);
            
            if (Files.exists(filePath)) {
                String contentType = getContentType(filePath.toString());
                byte[] content = Files.readAllBytes(filePath);
                
                exchange.getResponseHeaders().set("Content-Type", contentType);
                exchange.sendResponseHeaders(200, content.length);
                exchange.getResponseBody().write(content);
            } else {
                String response = "404 Not Found";
                exchange.sendResponseHeaders(404, response.length());
                exchange.getResponseBody().write(response.getBytes());
            }
            exchange.close();
        }

        private String getContentType(String path) {
            if (path.endsWith(".html")) return "text/html";
            if (path.endsWith(".css")) return "text/css";
            if (path.endsWith(".js")) return "application/javascript";
            return "text/plain";
        }
    }

    static class ParseHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!exchange.getRequestMethod().equals("POST")) {
                sendResponse(exchange, 405, "Method Not Allowed");
                return;
            }

            try {
                String contentType = exchange.getRequestHeaders().getFirst("Content-Type");
                if (contentType == null || !contentType.startsWith("multipart/form-data")) {
                    sendResponse(exchange, 400, "Expected multipart/form-data");
                    return;
                }

                String boundary = contentType.split("boundary=")[1];
                if (boundary.contains(";")) {
                    boundary = boundary.split(";")[0];
                }
                boundary = boundary.trim();

                byte[] bodyBytes = exchange.getRequestBody().readAllBytes();
                String body = new String(bodyBytes, StandardCharsets.UTF_8);

                String csvContent = extractCsvContent(body, boundary);
                
                if (csvContent == null) {
                    sendResponse(exchange, 400, "No file found in request");
                    return;
                }

                Path tempFile = Files.createTempFile("sales", ".csv");
                Files.writeString(tempFile, csvContent);
                
                ParseResult result = parser.parse(tempFile);
                
                Files.deleteIfExists(tempFile);

                String jsonResponse = toJson(result);
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                exchange.sendResponseHeaders(200, jsonResponse.length());
                exchange.getResponseBody().write(jsonResponse.getBytes(StandardCharsets.UTF_8));
                
            } catch (Exception e) {
                e.printStackTrace();
                sendResponse(exchange, 500, "Error: " + e.getMessage());
            }
            exchange.close();
        }

        private String extractCsvContent(String body, String boundary) {
            String boundaryMarker = "--" + boundary;
            String[] parts = body.split(boundaryMarker);
            
            for (String part : parts) {
                if (part.contains("filename=")) {
                    // Find the blank line that separates headers from content
                    int headerEnd = part.indexOf("\r\n\r\n");
                    if (headerEnd == -1) {
                        headerEnd = part.indexOf("\n\n");
                    }
                    
                    if (headerEnd != -1) {
                        String content = part.substring(headerEnd + 2).trim();
                        // Remove trailing boundary marker
                        if (content.endsWith("--")) {
                            content = content.substring(0, content.length() - 2).trim();
                        }
                        return content;
                    }
                }
            }
            return null;
        }

        private String toJson(ParseResult result) {
            StringBuilder json = new StringBuilder();
            json.append("{");
            json.append("\"summary\":{");
            json.append("\"totalSales\":").append(result.summary().totalSales()).append(",");
            json.append("\"averageSales\":").append(result.summary().averageSales()).append(",");
            json.append("\"validRowCount\":").append(result.summary().validRowCount()).append(",");
            json.append("\"errorCount\":").append(result.summary().errorCount());
            json.append("},");
            json.append("\"records\":[");
            for (int i = 0; i < result.records().size(); i++) {
                SaleRecord record = result.records().get(i);
                if (i > 0) json.append(",");
                json.append("{");
                json.append("\"date\":\"").append(record.date()).append("\",");
                json.append("\"product\":\"").append(escapeJson(record.product())).append("\",");
                json.append("\"quantity\":").append(record.quantity()).append(",");
                json.append("\"amount\":").append(record.amount());
                json.append("}");
            }
            json.append("],");
            json.append("\"errors\":[");
            for (int i = 0; i < result.errors().size(); i++) {
                ParseError error = result.errors().get(i);
                if (i > 0) json.append(",");
                json.append("{");
                json.append("\"lineNumber\":").append(error.lineNumber()).append(",");
                json.append("\"message\":\"").append(escapeJson(error.message())).append("\",");
                json.append("\"rawLine\":\"").append(escapeJson(error.rawLine())).append("\"");
                json.append("}");
            }
            json.append("]");
            json.append("}");
            return json.toString();
        }

        private String escapeJson(String s) {
            return s.replace("\\", "\\\\")
                     .replace("\"", "\\\"")
                     .replace("\n", "\\n")
                     .replace("\r", "\\r")
                     .replace("\t", "\\t");
        }

        private void sendResponse(HttpExchange exchange, int code, String response) throws IOException {
            exchange.sendResponseHeaders(code, response.length());
            exchange.getResponseBody().write(response.getBytes());
            exchange.close();
        }
    }
}
