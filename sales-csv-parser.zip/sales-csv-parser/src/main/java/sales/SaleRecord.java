package sales;

import java.math.BigDecimal;
import java.time.LocalDate;

public record SaleRecord(
        LocalDate date,
        String product,
        int quantity,
        BigDecimal amount
) {
}
