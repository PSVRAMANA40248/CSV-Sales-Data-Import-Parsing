package sales;

import java.util.List;

public record ParseResult(
        List<SaleRecord> records,
        List<ParseError> errors,
        SalesSummary summary
) {
}
