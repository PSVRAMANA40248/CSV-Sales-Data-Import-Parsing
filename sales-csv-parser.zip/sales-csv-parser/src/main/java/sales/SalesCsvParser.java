package sales;

import java.io.BufferedReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public final class SalesCsvParser {

    private static final List<String> EXPECTED_COLUMNS = List.of("date", "product", "quantity", "amount");
    private static final List<DateTimeFormatter> DATE_FORMATS = List.of(
            DateTimeFormatter.ISO_LOCAL_DATE,
            DateTimeFormatter.ofPattern("dd/MM/uuuu"),
            DateTimeFormatter.ofPattern("MM/dd/uuuu")
    );

    public ParseResult parse(Path filePath) throws IOException {
        return parse(filePath, Charset.forName("UTF-8"));
    }

    public ParseResult parse(Path filePath, Charset encoding) throws IOException {
        List<SaleRecord> records = new ArrayList<>();
        List<ParseError> errors = new ArrayList<>();
        BigDecimal totalSales = BigDecimal.ZERO;

        try (BufferedReader reader = Files.newBufferedReader(filePath, encoding)) {
            LogicalLineIterator lines = new LogicalLineIterator(reader);
            if (!lines.hasNext()) {
                return buildResult(records, errors, totalSales);
            }

            String headerLine = lines.next();
            List<String> headerFields = CsvFieldSplitter.split(headerLine);
            if (!isValidHeader(headerFields)) {
                errors.add(new ParseError(
                        1,
                        stripLineEnding(headerLine),
                        "Invalid header; expected columns: " + String.join(", ", EXPECTED_COLUMNS)
                ));
                return buildResult(records, errors, totalSales);
            }

            int lineNumber = 1;
            while (lines.hasNext()) {
                lineNumber++;
                String rawLine = lines.next();
                String strippedLine = stripLineEnding(rawLine);
                if (strippedLine.isBlank()) {
                    continue;
                }

                List<String> fields = CsvFieldSplitter.split(rawLine);
                RowParseOutcome outcome = parseRow(fields, lineNumber, strippedLine);
                if (outcome.error() != null) {
                    errors.add(outcome.error());
                    continue;
                }

                SaleRecord record = outcome.record();
                records.add(record);
                totalSales = totalSales.add(record.amount());
            }
        }

        return buildResult(records, errors, totalSales);
    }

    private ParseResult buildResult(
            List<SaleRecord> records,
            List<ParseError> errors,
            BigDecimal totalSales
    ) {
        int validCount = records.size();
        BigDecimal averageSales = validCount == 0
                ? BigDecimal.ZERO
                : totalSales.divide(BigDecimal.valueOf(validCount), 2, RoundingMode.HALF_UP);

        SalesSummary summary = new SalesSummary(
                totalSales,
                averageSales,
                validCount,
                errors.size()
        );
        return new ParseResult(records, errors, summary);
    }

    private boolean isValidHeader(List<String> fields) {
        if (fields.size() != EXPECTED_COLUMNS.size()) {
            return false;
        }

        for (int index = 0; index < EXPECTED_COLUMNS.size(); index++) {
            if (!fields.get(index).trim().equalsIgnoreCase(EXPECTED_COLUMNS.get(index))) {
                return false;
            }
        }
        return true;
    }

    private RowParseOutcome parseRow(List<String> fields, int lineNumber, String rawLine) {
        if (fields.size() != EXPECTED_COLUMNS.size()) {
            return RowParseOutcome.error(new ParseError(
                    lineNumber,
                    rawLine,
                    "Expected " + EXPECTED_COLUMNS.size() + " fields ("
                            + String.join(", ", EXPECTED_COLUMNS) + "), got " + fields.size()
            ));
        }

        String dateText = fields.get(0).trim();
        String product = fields.get(1).trim();
        String quantityText = fields.get(2).trim();
        String amountText = fields.get(3).trim();

        if (product.isEmpty()) {
            return RowParseOutcome.error(new ParseError(
                    lineNumber,
                    rawLine,
                    "Product name must not be empty"
            ));
        }

        LocalDate saleDate = parseDate(dateText);
        if (saleDate == null) {
            return RowParseOutcome.error(buildDateError(dateText, lineNumber, rawLine));
        }

        Integer quantity = parseQuantity(quantityText);
        if (quantity == null) {
            return RowParseOutcome.error(buildQuantityError(quantityText, lineNumber, rawLine));
        }

        BigDecimal amount = parseAmount(amountText);
        if (amount == null) {
            return RowParseOutcome.error(buildAmountError(amountText, lineNumber, rawLine));
        }

        if (quantity < 0) {
            return RowParseOutcome.error(new ParseError(
                    lineNumber,
                    rawLine,
                    "Quantity must be zero or positive"
            ));
        }

        if (amount.compareTo(BigDecimal.ZERO) < 0) {
            return RowParseOutcome.error(new ParseError(
                    lineNumber,
                    rawLine,
                    "Amount must be zero or positive"
            ));
        }

        return RowParseOutcome.success(new SaleRecord(saleDate, product, quantity, amount));
    }

    private LocalDate parseDate(String value) {
        if (value.isEmpty()) {
            return null;
        }

        for (DateTimeFormatter formatter : DATE_FORMATS) {
            try {
                return LocalDate.parse(value, formatter);
            } catch (DateTimeParseException ignored) {
                // Try the next supported format.
            }
        }

        return null;
    }

    private ParseError buildDateError(String value, int lineNumber, String rawLine) {
        if (value.isEmpty()) {
            return new ParseError(lineNumber, rawLine, "Date must not be empty");
        }
        return new ParseError(
                lineNumber,
                rawLine,
                "Invalid date '" + value + "'; expected one of: yyyy-MM-dd, dd/MM/yyyy, MM/dd/yyyy"
        );
    }

    private Integer parseQuantity(String value) {
        if (value.isEmpty()) {
            return null;
        }

        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private ParseError buildQuantityError(String value, int lineNumber, String rawLine) {
        if (value.isEmpty()) {
            return new ParseError(lineNumber, rawLine, "Quantity must not be empty");
        }
        return new ParseError(
                lineNumber,
                rawLine,
                "Invalid quantity '" + value + "'; expected an integer"
        );
    }

    private BigDecimal parseAmount(String value) {
        if (value.isEmpty()) {
            return null;
        }

        try {
            return new BigDecimal(value);
        } catch (NumberFormatException exception) {
            return null;
        }
    }

    private ParseError buildAmountError(String value, int lineNumber, String rawLine) {
        if (value.isEmpty()) {
            return new ParseError(lineNumber, rawLine, "Amount must not be empty");
        }
        return new ParseError(
                lineNumber,
                rawLine,
                "Invalid amount '" + value + "'; expected a number"
        );
    }

    private static String stripLineEnding(String line) {
        if (line.endsWith("\r\n")) {
            return line.substring(0, line.length() - 2);
        }
        if (line.endsWith("\n") || line.endsWith("\r")) {
            return line.substring(0, line.length() - 1);
        }
        return line;
    }

    private record RowParseOutcome(SaleRecord record, ParseError error) {
        static RowParseOutcome success(SaleRecord record) {
            return new RowParseOutcome(record, null);
        }

        static RowParseOutcome error(ParseError error) {
            return new RowParseOutcome(null, error);
        }
    }

    private static final class LogicalLineIterator {
        private final BufferedReader reader;
        private String nextLine;
        private boolean finished;

        LogicalLineIterator(BufferedReader reader) throws IOException {
            this.reader = reader;
            advance();
        }

        boolean hasNext() {
            return nextLine != null;
        }

        String next() throws IOException {
            if (nextLine == null) {
                throw new IllegalStateException("No more CSV lines available");
            }

            String current = nextLine;
            advance();
            return current;
        }

        private void advance() throws IOException {
            if (finished) {
                nextLine = null;
                return;
            }

            StringBuilder buffer = new StringBuilder();
            String physicalLine = reader.readLine();
            if (physicalLine == null) {
                finished = true;
                nextLine = buffer.length() == 0 ? null : buffer.toString();
                return;
            }

            buffer.append(physicalLine);
            while (!CsvFieldSplitter.hasBalancedQuotes(buffer.toString())) {
                physicalLine = reader.readLine();
                if (physicalLine == null) {
                    finished = true;
                    break;
                }
                buffer.append('\n').append(physicalLine);
            }

            nextLine = buffer.toString();
        }
    }

    public static String formatReport(ParseResult result) {
        StringBuilder report = new StringBuilder();
        report.append("Sales CSV Import Report").append(System.lineSeparator());
        report.append("=======================").append(System.lineSeparator());
        report.append("Valid rows:     ").append(result.summary().validRowCount()).append(System.lineSeparator());
        report.append("Malformed rows: ").append(result.summary().errorCount()).append(System.lineSeparator());
        report.append("Total sales:    ").append(result.summary().totalSales()).append(System.lineSeparator());
        report.append("Average sale:   ").append(result.summary().averageSales()).append(System.lineSeparator());

        if (!result.errors().isEmpty()) {
            report.append(System.lineSeparator()).append("Parse errors:").append(System.lineSeparator());
            for (ParseError error : result.errors()) {
                report.append("  Line ").append(error.lineNumber())
                        .append(": ").append(error.message())
                        .append(System.lineSeparator());
                report.append("    Raw: ").append(error.rawLine()).append(System.lineSeparator());
            }
        }

        return report.toString();
    }
}
