package sales;

import java.math.BigDecimal;

public record SalesSummary(
        BigDecimal totalSales,
        BigDecimal averageSales,
        int validRowCount,
        int errorCount
) {
}
