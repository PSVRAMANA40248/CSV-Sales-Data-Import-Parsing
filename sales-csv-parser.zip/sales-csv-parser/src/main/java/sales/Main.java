package sales;

public final class Main {

    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("Usage: java -jar sales-csv-parser.jar <path-to-csv>");
            System.exit(1);
        }

        SalesCsvParser parser = new SalesCsvParser();
        try {
            ParseResult result = parser.parse(java.nio.file.Path.of(args[0]));
            System.out.print(SalesCsvParser.formatReport(result));
            System.exit(result.errors().isEmpty() ? 0 : 1);
        } catch (java.io.IOException exception) {
            System.err.println("Failed to read file: " + exception.getMessage());
            System.exit(1);
        }
    }
}
