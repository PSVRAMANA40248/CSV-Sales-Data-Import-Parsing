package sales;

import java.util.ArrayList;
import java.util.List;

final class CsvFieldSplitter {

    private CsvFieldSplitter() {
    }

    static List<String> split(String line) {
        List<String> fields = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean insideQuotes = false;
        int index = 0;
        String text = stripLineEnding(line);

        while (index < text.length()) {
            char character = text.charAt(index);

            if (character == '"') {
                if (insideQuotes && index + 1 < text.length() && text.charAt(index + 1) == '"') {
                    current.append('"');
                    index += 2;
                    continue;
                }
                insideQuotes = !insideQuotes;
                index++;
                continue;
            }

            if (character == ',' && !insideQuotes) {
                fields.add(current.toString());
                current.setLength(0);
                index++;
                continue;
            }

            current.append(character);
            index++;
        }

        fields.add(current.toString());
        return fields;
    }

    static boolean hasBalancedQuotes(String text) {
        boolean insideQuotes = false;
        int index = 0;

        while (index < text.length()) {
            char character = text.charAt(index);
            if (character == '"') {
                if (insideQuotes && index + 1 < text.length() && text.charAt(index + 1) == '"') {
                    index += 2;
                    continue;
                }
                insideQuotes = !insideQuotes;
            }
            index++;
        }

        return !insideQuotes;
    }

    private static String stripLineEnding(String line) {
        if (line.endsWith("\r\n")) {
            return line.substring(0, line.length() - 2);
        }
        if (line.endsWith("\n") || line.endsWith("\r")) {
            return line.substring(0, line.length() - 1);
        }
        return line;
    }
}
