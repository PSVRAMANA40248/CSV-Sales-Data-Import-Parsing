package sales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalesCsvApplication {
    public static void main(String[] args) {		
        SpringApplication.run(SalesCsvApplication.class, args);
    }
}
